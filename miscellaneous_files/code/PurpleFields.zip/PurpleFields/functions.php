<?php

if ( function_exists('register_sidebar') )

    register_sidebar();


add_theme_support('post-thumbnails');
add_theme_support('automatic-feed-links');
add_theme_support('post-formats');

?>