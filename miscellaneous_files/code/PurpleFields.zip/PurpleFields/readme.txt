Special Modifications:

To make links appear in the tree branches of the right-hand corner, you need to tag
up to two pages with the custom field "showintree" and set that value equal to 2.
If the names of the pages are slightly too long and overlap with the tree branch, you 
can adjust their placement in style.css by going to "firstlink" and "secondlink"
and changing the attribute padding-right.  (Increasing the number will push the start
of the link further to the left, which you will want if the page names are too long.)