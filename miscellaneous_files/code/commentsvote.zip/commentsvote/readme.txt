=== Comments Vote ===
Contributors: The Bivings Group
Creator link: http://www.bivings.com/
Tags: comments, vote
Requires at least: 2.5
Tested up to: 2.7
Stable tag: 1.0

This plugin enables website users to vote comments up or down.

== Description ==

This plug-in enables users of the website to vote comments up or down. 
This running tally can be displayed on the comment, and administrators 
have the ability to activate the collapsing of comments with a 
designated negative rating. The comment will still be available for 
viewing by clicking on a "show comment" link, which expands to show the 
collapsed comment's contents.  Flagged comments will be displayed in a 
flagged comments submenu, through which moderators can approve comments.  
A form to allow easy emailing of reasons for flagging to the moderator 
is also provided.

== Installation ==

1. Upload the 'commentsvote' directory to the '/wp-content/plugins/' 
directory
2. Activate the plugin through the 'Plugins' menu in WordPress 

== Frequently Asked Questions ==

= Can the styles be changed? =

Yes. To change the vote count style, edit the style.css file located in 
the plugin directory. To change the vote images, replace the vote_up.jpg 
and vote_down.jpg images located in the plugin directory.

= Can I change the preferences? =

Yes. After activating the plugin, login to wp-admin as the 
administrator, click Settings, then click Comments Vote.

= How do I get flagged comments emailed to me? =
Edit the $email variable in emailform.php

