import java.util.Scanner;

class runCMD {
	
	CMD player,comp1,comp2;
		
	/**
	*  This is the main method for the program.  Creates an instance so that non-static
	*  methods can be used.  Calls startUp, which gives instructions and assigns character
	*  to player, and then runGame, which is the heart of the game.
	**/
	public static void main (String [] args)
    {
    	runCMD instance = new runCMD();
		instance.startUp();
		instance.runGame();
	}
					
	/**
	*  This method walks the player through the introduction and choice of character before
	*  sending player on to the game itself.  When player picks a character, method calls upon
	*  the catmousedog class to instantiate three animal objects.  Whichever character the player
	*  has chosen is marked as their character, while the others are designated to the computer.
	**/
	public void startUp() 
	{		
		System.out.println("Welcome to Cat, Mouse, Dog!  In this game, you will play either a mouse, a dog, or a cat intent on destroying the other animals and ruling the world!  ... or at least the house.");
		System.out.println("To get instructions, enter the letter I.  To continue on with the game, press C.");
		String cont = getResp('C');
		
		if (cont.equals("I")) {
			Instructions(); 
		}
		
		System.out.println("What animal do you want to be?  (C)at, (M)ouse, (D)og ");
		String choice = getResp('A');
		
		createCMD(choice);
		
		System.out.println("Okay, you're ready to begin!");	
	}
	
	/** 
	*  Prints instructions to the screen.
	**/
	public void Instructions() {
		System.out.println("*******************************************");
		System.out.println();	
		System.out.println("The goal of this game is to be the last animal standing!  Run through the");
		System.out.println("house and defeat the other two characters by attacking them and bringing");
		System.out.println("their health points down to zero.  In addition to attacking, you can move");
		System.out.println("left or right, or stay still.");
		System.out.println();	
		System.out.println("What's the difference between the cat, mouse, and dog characters?  First,");
		System.out.println("each animal has a foe that they can beat more easily.  The cat beats the mouse");
		System.out.println("beats the dog beats the cat.  This doesn't mean the cat can't hurt the dog, it");
		System.out.println("is just less likely to.");
		System.out.println();
		System.out.println("Second, each character has special strengths and weaknesses.  The cat can");
		System.out.println("move extra fast, having two turns in one.  However, the cat is also very");
		System.out.println("sleepy.  Sometimes, it will 'fall asleep' and not awake until something else");
		System.out.println("enters the room.");
		System.out.println();
		System.out.println("The dog has a great sense of smell, and it can 'smell' where the other");
		System.out.println("characters are.  However, it is easily distractable.  The dog will sometimes");
		System.out.println("randomly do something else, no matter what you tell it to do.");
		System.out.println();
		System.out.println("The mouse can find little pieces of cheese.  For each piece of cheese the");
		System.out.println("mouse finds, it gains back one health point.  However, when fighting the dog");
		System.out.println("or the cat, it loses a greater number of hit points (4 instead of 3).");
		System.out.println();
		System.out.println("*******************************************");
	}
	
	/**
	*  This method, which accepts the player's choice of animal, creates three objects of class
	*  CMD, assigning to object player the animal they chose.
	**/
	public void createCMD(String choice) 
	{
		if (choice.equals("C")) 
		{
			player = new CMD("Cat",10,3,'C','M');
			comp1 = new CMD("Dog",10,5,'D','C');
			comp2 = new CMD("Mouse",10,8,'M','D');
		} else if (choice.equals("D")) {
			comp1 = new CMD("Cat",10,3,'C','M');
			player = new CMD("Dog",10,5,'D','C');
			comp2 = new CMD("Mouse",10,8,'M','D');
		} else if (choice.equals("M")) {
			comp1 = new CMD("Cat",10,3,'C','M');
			comp2 = new CMD("Dog",10,5,'D','C');
			player = new CMD("Mouse",10,8,'M','D');
		}	
	}
	
	/**
	*  This method is the heart of the game.  While player one still has health points,
	*  and while at least one of the two computer characters is alive, continues.  Each
	*  turn: 1) map and health is displayed, 2) the user picks whether to move, attack,
	*  or sit still, 3) either move or attack functions are executed, and finally the
	*  computer goes.  Once the player or both computer chars die, "You win!"/"You lose!"
	*  is printed.  Method playerTurn is called each round, with modification for each
	*  character within that method.
	**/
	public void runGame() 
	{
		String catStatus = "Awake";
		int cheeseLoc = placeCheese();
	
		while ((player.health > 0) && ((comp1.health > 0) || (comp2.health > 0))) 
		{
			displayMapHealth(cheeseLoc);
			
			catStatus = playerTurn(player.symb, catStatus, cheeseLoc);
			
			if (player.symb == 'M') {
				cheeseLoc = cheese(cheeseLoc);
				ComputerGoes();
			} else {			
				ComputerGoes();
				cheeseLoc = cheese(cheeseLoc);
			}
				
		}			
			
		if (player.health > 0) {
			System.out.println("You win!");
		} else {
			System.out.println("You lose!");
		}
	}
	
	/** 
	*  This method creates a map and a chart of health points and displays them,
	*  calling on lineArray to plot the characters into their appropriate place.
	**/
	public void displayMapHealth(int cheeseLoc) 
	{
		
		char[] lineArray = {'|', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '|'}; 
		lineArray = getAnimalArray(lineArray,cheeseLoc);
		
		String locationline = new String(lineArray);

		System.out.println("    1       2       3       4       5       6       7       8    ");
		System.out.println("|-------|-------|-------|-------|-------|-------|-------|-------|");
        System.out.println("|       |       |       |       |       |       |       |       |");
		System.out.println(locationline);
		System.out.println("|       |       |       |       |       |       |       |       |");
		System.out.println("|-------|-------|-------|-------|-------|-------|-------|-------|");
		System.out.println();
		System.out.println("----------------------------");
		System.out.println("        HEALTH POINTS       ");
		System.out.println(player.name + ": " + ifDead(player.health));
		System.out.println(comp1.name + ": " + ifDead(comp1.health)); 
		System.out.println(comp2.name + ": " + ifDead(comp2.health)); 
		System.out.println("----------------------------");
		System.out.println();
		System.out.println("What do you want to do?  (R)ight, (L)eft, (A)ttack, (S)tay:");

	}
	
	/**
	*  Method plots animals on array to be displayed.  If dog, displays all.  If cat or mouse,
	*  displays when in the same room.  If mouse, displays if cheese is in room.
	**/
	public char[] getAnimalArray(char[] lineArray,int cheeseLoc) 
	{
		lineArray[(player.loc - 1)*8 + 4] = player.symb;
		if (player.symb == 'D') {
			if (comp1.health > 0) {
				lineArray[(comp1.loc - 1)*8 + 2] = comp1.symb;
			}
			if (comp2.health > 0) {
				lineArray[(comp2.loc - 1)*8 + 6] = comp2.symb;
			}
		} 
		if ((player.loc == comp1.loc) && (comp1.health > 0)){
			lineArray[(comp1.loc - 1)*8 + 2] = comp1.symb;
		}
		if ((player.loc == comp2.loc) && (comp2.health > 0)) {
			lineArray[(comp2.loc - 1)*8 + 6] = comp2.symb;
		}	
		return lineArray;		
	}
	
	/**
	*  Method computes if health is > 0.  If not, displays: "Defeated!"
	**/
	public String ifDead(int health) 
	{
		if (health > 0) {
			String healthStr = Integer.toString(health);
			return healthStr; 
		} else {
			return "Defeated!";
		}	
	}
	
	/**
	*  If the dog is going, there's a 40% chance of it being distracted,
	*  if the cat is going, it can go twice, unless it falls asleep, in which
	*  case it is asleep until another animal enters the room.
	*/
	public String playerTurn(char animal, String catStatus, int cheeseLoc) 
	{
		if (animal == 'D') {
			if (Math.random() > .7) {
				System.out.println("You got distracted by " + randomThing() + " in the other room!");
				player.randomMove();
			} else {
				moveChoiceExecute(getResp('M'));
			}
		}
		
		if (animal == 'C') {
			if (catStatus.equals("Awake")) {
				catStatus = isSleeping(catStatus);
				if (catStatus.equals("Awake")) {
					moveChoiceExecute(getResp('M'));
					displayMapHealth(cheeseLoc);
					System.out.println("You get to go again!");
					moveChoiceExecute(getResp('M'));
				}
			}
			if (catStatus.equals("Asleep")) {
				System.out.println("Shhhhh!  The cat is sleeping!");
			}
		}
		
		if (animal == 'M') {
			moveChoiceExecute(getResp('M'));
		}
		return catStatus;
	}
	
	/**
	*  This method executes the choice by calling either animalAttack or animalMove.
	**/
	public void moveChoiceExecute(String move) 
	{
		if (move.equals("A")) {
			animalAttack();				
		} else if ((move.equals("L")) || (move.equals("R"))) {
			player.animalMove(move);
		}	
	}
	
	/**
	*  This method returns a random thing for the dog to get distracted by.
	**/
	public String randomThing() 
	{
		String[] thingArray = {"a crumpled piece of paper","a centipede","a cell phone ringing","an alarm clock","a shoe","an old sock","a child playing","a slant of light","a bone","some dust balls"};	
		return thingArray[(int)(Math.random()*10)];	
	}
	
	/**
	*  There is a one in five chance that the cat will fall asleep.  If there is no one else in
	*  the room, it remains asleep.
	**/
	public String isSleeping(String Previous) 
	{
		if (Previous.equals("Asleep")) {
			if ((player.loc == comp1.loc) || (player.loc == comp2.loc)) {
				return "Awake";
			}
			else return Previous;
		} else {
			if (Math.random() > .6) {
				return "Asleep";
			} else {
				return Previous;
			}
		}	
	}
	
	/**
	*  This method handles attacks between the player animal and one of the
	*  two computer animals.  If two computer animals are available to attack
	*  prompts the user to pick, otherwise automatically chooses the one in
	*  the room.  Animals are fed to fight method.
	**/
	public void animalAttack() 
	{
		char attackAnimal;

		if ((player.loc == comp1.loc) && (player.loc == comp2.loc) && (comp1.health > 0) && (comp2.health > 0)) {
			System.out.println("There are two foes within striking distance!  Which one do you want to attack?  (Enter " + comp1.symb + " or " + comp2.symb + "):");
			String attack = getResp('F');
			if (attack.charAt(0) == comp1.symb) {
				fight(player, comp1);
			} else {
				if ((attack.charAt(0) == comp2.symb)) {
				fight(player, comp2);
				}
			}
		} else {
			if ((player.loc == comp1.loc) && (comp1.health > 0)) {
				fight(player, comp1);
			}
			if ((player.loc == comp2.loc) && (comp2.health > 0)) {
				fight(player, comp2);
			}
		}				
	}
	
	/**
	*  Fight method takes two animals.  Each animal (cat/mouse/dog) has another animal it
	*  "beats" (that is, has a higher likelihood of winning against).  If animal is facing
	*  off against animal it beats, feeds good likelihood to strike method.  Else, animal is
	*  facing off animal that beats it, and bad likelihood is fed to strike method.
	**/
	public void fight(CMD animal1, CMD animal2) 
	{
		System.out.println(animal1.name + " vs " + animal2.name + "... fight!");
		
		if (animal1.beats == animal2.symb) {
			animal2.health += strike(.7,animal1.name,animal2.name);
		} else {
			animal2.health += strike(.3,animal1.name,animal2.name);
		}
	}

	/**
	*  Strike method takes in a likelihood (between 0 and 1).  Uses this to 
	*  modulate random chance of hitting the defender.  Prints out a statement saying what
	*  happened.
	**/
	public int strike(double likelihood, String offend, String defend) 
	{
		int hit = 0;
		double randomStrike = Math.random();
		if (randomStrike <= likelihood) {
			if (defend.equals("Mouse")) {
				hit = -4;
			} else {
				hit = -3;
			}
			System.out.println(offend + " strikes " + defend + " for " + hit + " health points!");	
		} else {
			System.out.println(offend + " misses " + defend + "!");
		}
		return hit;
	}
	
	/**
	*  This method checks to see if there is cheese in the room and, if so, has mouse eat it.
	**/
	public int cheese(int cheeseLoc) 
	{
		CMD[] animal = {player,comp1,comp2};
		for (int i = 0; i < 3; i++) {
			if ((animal[i].symb == 'M') && (animal[i].loc == cheeseLoc) && (animal[i].health > 0)) {
				animal[i].health += 1;
				System.out.println("The mouse has found some cheese!  He gains 1 health point.");
				cheeseLoc = placeCheese();
			}
		}
		return cheeseLoc;	
	}
	
	/**
	*  This method randomly places a piece of cheese in one of the 8 rooms.
	**/
	public int placeCheese() 
	{
		int goAheadCheese = 0;
		int cheeseLoc = 0;
		while (goAheadCheese == 0) {
			cheeseLoc = (int)(Math.random()*10);
			if ((cheeseLoc > 8) || (cheeseLoc == 0)) {
				cheeseLoc = (int)(Math.random()*10);
			}
			else {
				goAheadCheese = 1;
			}
		}
		return cheeseLoc;
	}
	
	/**
	*  This method moves for the computer characters.  For each comp character, if
	*  still alive, goes.   Moves randomly unless it sees prey, then attacks, or,
	*  if other animal is defeated, always attacks remaining one.
	**/
	public void ComputerGoes() 
	{	
		CMD[] animal = {comp1,comp2,comp1};
		int catTurn = 0;
		
		for (int i = 0; i < 2; i++) {
			if (animal[i].health > 0) {
				System.out.println(animal[i].symb + "'s turn!");
				if ((animal[i].loc == player.loc) && ((animal[i].beats == player.symb) || (animal[i+1].health < 0))) {
					fight(animal[i],player);
				} else if (((animal[i].loc == animal[i+1].loc) && (animal[i+1].health > 0)) && ((animal[i].beats == animal[i+1].symb) || (player.health < 0))) {
					fight(animal[i],animal[i+1]);
				} else {
					animal[i+1].randomMove();
				}
				if ((animal[i].symb == 'C') && (catTurn == 0)) {
			    	i -= 1;
			    	catTurn = 1;
				} 
			}
		}	
	}

	/**
	*  There are four different types of user input accepted in this game, all
	*  as characters.  This method inputs parameter questionType to 
	*  indicate how to evaluate the responses.  Prompts for response, checks that 
	*  the response is valid.  If not, prints error and continues.  If so,
	*  returns response.
	**/
	public String getResp(char questionType) 
	{
			int inputcount = 0;
			int goAhead = 0;
			String readline = " ";
			
			while (goAhead != 1) 
			{
				Scanner keyboard = new Scanner(System.in);
				readline = keyboard.nextLine();	
				
				if (inputcount > 0) {
					System.out.println("Incorrect command. Please try again.");
				}	
				
				if (questionType == 'F') {	
					if ((readline.equals("C")) || (readline.equals("M")) ||(readline.equals("D"))) {
						if (player.symb == readline.charAt(0)) {
							System.out.println("You can't attack yourself!");
						}
						else {
							goAhead = 1;
						}
					}
				}
				
				if (questionType == 'M') {
					if ((readline.equals("R")) || (readline.equals("L")) ||(readline.equals("A")) || (readline.equals("S"))) {
						if (readline.equals("A")) { 
							if ((player.loc != comp1.loc) && (player.loc != comp2.loc)) {
								System.out.println("You have no one to attack!");	
							} else {
								goAhead = 1;
							}
						} else {
							goAhead = 1;
						}
					}
				}
				
				if (questionType == 'A') {	
					if ((readline.equals("C")) || (readline.equals("M")) ||(readline.equals("D"))) {
						goAhead = 1;	
					}
				}
				
				if (questionType == 'C') {	
					if ((readline.equals("C")) || (readline.equals("I"))) {
						goAhead = 1;	
					}
				}
				
				inputcount++;		
			}
			return readline;
	}		
		
}
